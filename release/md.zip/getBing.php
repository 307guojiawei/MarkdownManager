<?php
    function getBing()
    {
        $str=file_get_contents('http://cn.bing.com/HPImageArchive.aspx?idx=0&n=5');
        if(preg_match_all("/<urlBase>(.+?)<\/urlBase>/ies",$str,$matches)){
             if(isset($_GET['num']))
             {
                $imgurl='http://cn.bing.com'.(($matches[1])[$_GET['num']])."_1920x1080.jpg";
             }else{
                $imgurl='http://cn.bing.com'.(($matches[1])[rand(0,4)])."_1920x1080.jpg";
             }
          
        }
        //var_dump($imgurl);
        if($imgurl){
           return $imgurl;
        }else{
           exit('error');
        }
    }
    
     
?>